Note: For this to work you need a Java Runtime Environment (JRE)

Where to get a JRE:
Visit https://www.oracle.com/java/technologies/javase-jdk11-downloads.html and download the version for your pc
Run the installer and install the Java SE
The Java SE comes with a JRE, you should now be able to run this

WARNING: This code is under the Creative Commons Attribution-NonCommercial-NoDerivs Liscence. 
YOU MAY NOT SELL OR USE THIS CODE FOR PROFITABLE GAIN
YOU MAY NOT MODIFY AND DISTRIBUTE MY CODE (You may Modify it, but you cannot repost the modified version)
YOU MUST GIVE CREDIT TO THE ORIGINAL CREATOR OF THIS CODE WHEN REPUBLISHING IT
FAILURE TO FOLLOW THESE RULES IS A BREACH OF THE CREATIVE COMMONS LISCENCE AND AGAINST THE LAW.
https://creativecommons.org/licenses/by-nc-nd/4.0/ For more information.